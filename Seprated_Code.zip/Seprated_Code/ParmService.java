package com.eligible.flag.service;


import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;

import com.eligible.flag.bean.DIDIRequestBean;
import com.eligible.flag.exception.DIDIException;
import com.eligible.flag.util.DIDIExceptionHandler;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fca.vip.framework.database.DataSourceConfiguration;

public class ParmService {

	private static Logger logger = LogManager.getLogger(ParmService.class);

	ObjectMapper objectMapper = new ObjectMapper();
	JdbcTemplate jdbcTemplate = DataSourceConfiguration.getJdbcTemplate();

	public ParmService() {
 
	}

	public ParmService(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public String mapFirstCharWithFullBrandName(String brandFromService) {
		logger.debug("Entering ParmService : mapFirstCharWithFullBrandName");
		brandFromService = brandFromService.trim();
		String brand = brandFromService.substring(1, brandFromService.length() - 1);
		String expandedBrandString = "";
		logger.debug("brand %s", brand);
		if ("J".equalsIgnoreCase(brand))
			logger.debug("ParmService \"J\".equalsIgnoreCase(brand)");
		if ("B".equalsIgnoreCase(brand)) {
			expandedBrandString = "PSA";
		} else if ("C".equalsIgnoreCase(brand)) {
			expandedBrandString = "CHRYSLER";
		} else if ("D".equalsIgnoreCase(brand)) {
			expandedBrandString = "DODGE";
		} else if ("E".equalsIgnoreCase(brand)) {
			expandedBrandString = "EAGLE";
		} else if ("F".equalsIgnoreCase(brand)) {
			expandedBrandString = "FEIGHTLINER";
		} else if ("J".equalsIgnoreCase(brand)) {
			logger.debug("else if (\"J\".equalsIgnoreCase(%s)", brand);
			expandedBrandString = "JEEP";
			logger.debug("expandedBrandString %s", expandedBrandString);
		} else if ("M".equalsIgnoreCase(brand)) {
			expandedBrandString = "MASERATI";
		} else if ("R".equalsIgnoreCase(brand)) {
			expandedBrandString = "RAM";
		} else if ("T".equalsIgnoreCase(brand)) {
			expandedBrandString = "MOPAR";
		} else if ("V".equalsIgnoreCase(brand)) {
			expandedBrandString = "VOLKSWAGEN";
		} else if ("X".equalsIgnoreCase(brand)) {
			expandedBrandString = "FIAT";
		} else if ("Y".equalsIgnoreCase(brand)) {
			expandedBrandString = "ALFA ROMEO";
		} else if ("Z".equalsIgnoreCase(brand)) {
			expandedBrandString = "LANCIA";
		}

		logger.debug("Exiting ParmService : mapFirstCharWithFullBrandName expandedBrandString %s", expandedBrandString);
		return expandedBrandString;

	}

	public String removeDoubleCodeFromStartAndEnd(String str) {
	    if (str == null || str.isEmpty()) {
	        return "";
	    }

	    StringBuilder ans = new StringBuilder();
	    for (int i = 1; i < str.length() - 1; i++) {
	        ans.append(str.charAt(i));
	    }

	    return ans.toString();
	}


	public Map<Integer, Map<String, String>> getParmData(Map<String, Object> dataMap) throws DIDIException {
		logger.debug("Entering ParmService : getParmData");
		String brandFromVIPService = (String) dataMap.get("brand");
		String brand = mapFirstCharWithFullBrandName(brandFromVIPService);

		String modelYearFromVIPService = (String) dataMap.get("modelYear");
		String modelYear = removeDoubleCodeFromStartAndEnd(modelYearFromVIPService);

		String bodyModelFromVIPService = (String) dataMap.get("bodyStyle");
		String bodyModel = removeDoubleCodeFromStartAndEnd(bodyModelFromVIPService);

		String engineScFromVIPService = (String) dataMap.get("engine");
		String engineSC = removeDoubleCodeFromStartAndEnd(engineScFromVIPService);

		String transmissionSCFromVIPService = (String) dataMap.get("transmission");
		String transmissionSC = removeDoubleCodeFromStartAndEnd(transmissionSCFromVIPService);

		logger.debug("ParmService : getParmData Point 101 %s--%s--%s--%s--%s", brand, modelYear, bodyModel, engineSC, transmissionSC);


		StringBuilder queryBuilder = new StringBuilder(
				"SELECT C_MKT AS MARKET, C_BRND AS BRAND, I_MOD_YR AS MODEL_YEAR, ")
				.append("C_BODY_MODEL AS BODY_MODEL, C_ENGINE_SC AS ENGINE_SC , C_TRANS_SC AS TRANS_SC, ")
				.append("C_DLR AS DEALER_CODE, C_ZONE AS ZONE , C_LANG AS LANG, Q_MIS AS MIS, ")
				.append("L_ELIG AS ELIGIBILITY_FLAG,")
				.append("X_MSG AS ELIGIBILITY_MESSAGE, C_ZONE AS ZONE , C_LANG AS LANG, Q_MIS AS MIS, ")
				.append("C_LOP12 AS LOP1_2, C_LOP34 AS LOP3_4, C_LOP56 AS LOP5_6, C_LOP78 AS LOP7_8 FROM SDIDPARM ")
				.append("WHERE C_MKT IN (?,'*') AND C_BRND IN (?,'*') AND I_MOD_YR IN (?,'*') AND C_BODY_MODEL IN (?,'*') AND C_ENGINE_SC IN (?,'*') AND C_TRANS_SC IN (?,'*') ")
				.append("AND C_DLR IN (?,'*') AND C_ZONE IN (?,'*') AND C_LANG IN (?,'*') AND C_LOP12 IN (?,'*') AND C_LOP34 IN (?,'*') AND C_LOP56 IN (?,'*') ")
				.append("AND C_LOP78 IN(?,'*') AND L_REC_STAT ='A' AND CURDATE() BETWEEN D_STMP_EFF_STRT AND D_STMP_EFF_END");

		String sql = queryBuilder.toString();
		logger.debug("ParmService : getParmData Point 102 %s", sql);
		List<Map<String, String>> data = new ArrayList<>();
		DIDIRequestBean requestBean = (DIDIRequestBean) dataMap.get("requestBean");
		
		//MODIFIED START
		logger.debug("ParmService : getParmData Point 103 requestBean.getDealerMarket() {} brand {} modelYear {} bodyModel {} engineSC {} transmissionSC {} requestBean.getDealerCode() {} requestBean.getDealerZone() {} requestBean.getDealerLanguage() {} (String) dataMap.get(\"lop12\") {} (String) dataMap.get(\"lop34\") {} (String) dataMap.get(\"lop56\") {} (String) dataMap.get(\"lop78\") {}",
			    requestBean.getDealerMarket(), brand, modelYear, bodyModel, engineSC, transmissionSC,
			    requestBean.getDealerCode(), requestBean.getDealerZone(), requestBean.getDealerLanguage(),
			     dataMap.get("lop12"), dataMap.get("lop34"),
			    dataMap.get("lop56"),  dataMap.get("lop78"));

	
		try {
			logger.debug("ParmService : getParmData sql before {}", sql);
			data = jdbcTemplate.query(sql, new PreparedStatementSetter() {
				public void setValues(PreparedStatement preparedStatement) throws SQLException {
					preparedStatement.setString(1, requestBean.getDealerMarket());
					preparedStatement.setString(2, brand);
					preparedStatement.setString(3, modelYear);
					preparedStatement.setString(4, bodyModel);
					preparedStatement.setString(5, engineSC);
					preparedStatement.setString(6, transmissionSC);
					preparedStatement.setString(7, requestBean.getDealerCode());
					preparedStatement.setString(8, requestBean.getDealerZone());
					preparedStatement.setString(9, requestBean.getDealerLanguage());
					preparedStatement.setString(10, (String) dataMap.get("lop12"));
					preparedStatement.setString(11, (String) dataMap.get("lop34"));
					preparedStatement.setString(12, (String) dataMap.get("lop56"));
					preparedStatement.setString(13, (String) dataMap.get("lop78"));
					logger.debug("ParmService : getParmData Point 104");
				}
			}, rs -> {
				List<Map<String, String>> entities = new ArrayList<>();
				int numberOfRecords = 0;
				ResultSetMetaData metaData = rs.getMetaData();
				int columnCount = metaData.getColumnCount();
				logger.debug("ParmService : getParmData Point 105 metaData {} columnCount {}", metaData, columnCount);

				while (rs.next()) {
					numberOfRecords++;
					logger.debug("ParmService : getParmData numberOfRecords {}", numberOfRecords);

					Map<String, String> map = new LinkedHashMap<>();
					for (int i = 1; i <= columnCount; i++) {
						String columnName = metaData.getColumnName(i);
						Object columnValue = rs.getObject(i);
						map.put(columnName, columnValue.toString());
					}
					entities.add(map);
					logger.debug("ParmService : getParmData Point 105 map {} entities {}", map, entities.size());
				}

				return entities;
			});
		} catch (Exception e) {
			new DIDIExceptionHandler().throwDIDIException("ParmService : getParmData :: " + e.getMessage());
		}

		logger.debug("Exiting ParmService : getParmData data {}", data);

		return this.rankLogic(data);
	}
    private static final String STARTCOUNT= "startCount";
     
	public Map<Integer, Map<String, String>> rankLogic(List<Map<String, String>> data) {
		logger.debug("Entering ParmService : rankLogic");
		Map<String, Object> resultMap = this.rowFilterOnMaxStarColumn(data);
		@SuppressWarnings("unchecked")
		List<Map<String, String>> rowFilterOnMaxStarColumn = (List<Map<String, String>>) resultMap.get("data");
		
		int startCount = (int) resultMap.get(STARTCOUNT);
		List<Map<String, String>> filteredList = new ArrayList<>();
		int maxStartCount = Integer.MIN_VALUE;
		String startCountStr = "";
		int startCount1 = 0;
		for (Map<String, String> map : rowFilterOnMaxStarColumn) {
			startCountStr = map.get(STARTCOUNT);
			if (startCountStr != null) {
				startCount1 = Integer.parseInt(startCountStr);
				if (startCount1 > maxStartCount) {
					maxStartCount = startCount1;
					filteredList.clear(); // Clear the list as we found a new maximum
					filteredList.add(map);
				} else if (startCount == maxStartCount) {
					filteredList.add(map);
				}
			}
		}

		Map<Integer, Map<String, String>> rowDataWithRankNo = this.rowDataWithRankNo(filteredList);
		Optional<Entry<Integer, Map<String, String>>> entryWithHighestKey = rowDataWithRankNo.entrySet().stream()
				.max(Map.Entry.comparingByKey());

		entryWithHighestKey.ifPresent(entry -> {
			rowDataWithRankNo.clear();
			rowDataWithRankNo.put(entry.getKey(), entry.getValue());
		});
		logger.debug("Entering ParmService : rankLogic and the rowDataWithRankNo is {}", rowDataWithRankNo);
		return rowDataWithRankNo;
	}
	//MODIFIED END
	
	private Map<String, Object> rowFilterOnMaxStarColumn(List<Map<String, String>> data) {
		Map<String, Object> resultMap = new HashMap<>();
		List<Map<String, String>> rowFilterOnMaxStarColumn = new ArrayList<>();
		int startCount = 0;
		Map<String, String> row = null;
		String value = null;
		for (Map<String, String> map : data) {
			startCount = 0;
			// each row
			for (Map.Entry<String, String> entry : map.entrySet()) {
				value = entry.getValue();
				if (!value.equals("*")) {
					startCount++;
				}
			}
			row = map;
			row.put(STARTCOUNT, startCount + "");
			rowFilterOnMaxStarColumn.add(row);
		}
		resultMap.put("data", rowFilterOnMaxStarColumn);
		resultMap.put(STARTCOUNT, startCount);
		return resultMap;
	}

	private Map<Integer, Map<String, String>> rowDataWithRankNo(List<Map<String, String>> filteredList) {
		Map<Integer, Map<String, String>> rowDataWithRankNo = new LinkedHashMap<>();
		int totalRankCount = 0;
		String eachColumKeyName = "";
		String eachColumnValue = "";
		
//MODIFIED START
		for (Map<String, String> eachRow : filteredList) {

			totalRankCount = 0;
			for (Map.Entry<String, String> eachColumn : eachRow.entrySet()) {
				eachColumKeyName = eachColumn.getKey();
				eachColumnValue =  eachColumn.getValue();
				
				if (!eachColumnValue.equals("*")) {
					if (eachColumKeyName.equals("C_ENGINE_SC")) {
						totalRankCount += 5000;
					} else if (eachColumKeyName.equals("C_TRANS_SC")) {
						totalRankCount += 3000;
					} else if (eachColumKeyName.equals("C_BRND")) {
						totalRankCount += 1000;
					} else if (eachColumKeyName.equals("C_BODY_MODEL")) {
						totalRankCount += 500;
					} else if (eachColumKeyName.equals("I_MOD_YR")) {
						totalRankCount += 200;
					} else if (eachColumKeyName.equals("C_ZONE")) {
						totalRankCount += 100;
					} else if (eachColumKeyName.equals("C_DLR")) {
						totalRankCount += 50;
					} else if (eachColumKeyName.equals("LOP1_2")) {
						totalRankCount += 20;
					} 
				}
			}
			rowDataWithRankNo.put(totalRankCount, eachRow);
			logger.debug("Map<String, String> eachRow {} totalRankCount {}", eachRow, totalRankCount);
		}
		return rowDataWithRankNo;
	}
}
//MODIFIED END
