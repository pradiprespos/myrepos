package com.eligible.flag.service.didielig;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TimeZone;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;

import com.eligible.flag.bean.DIDIRequestBean;
import com.eligible.flag.bean.DIDIResponse;
import com.eligible.flag.bean.DIDIResponseBean;
import com.eligible.flag.bean.InsertIntoAuditTableBean;
import com.eligible.flag.bean.RepairOrderBean;
import com.eligible.flag.exception.DIDIException;
import com.eligible.flag.service.ParmService;
import com.eligible.flag.util.DIDIExceptionHandler;
import com.eligible.flag.util.VipBasicServiceAWSCloud;
import com.eligible.flag.validation.didielig.DIDIEligibilityRequestInputValidation;
import com.fca.vip.framework.database.DataSourceConfiguration;

public class DIDIEligibilityServiceImpl implements DIDIEligibilityService {

	private DIDIEligibilityRequestInputValidation validation = new DIDIEligibilityRequestInputValidation();
	private ParmService parmService = new ParmService();
	private DIDIResponse didiResponse = new DIDIResponse();
	JdbcTemplate jdbcTemplate = DataSourceConfiguration.getJdbcTemplate();
	private static final String SUCCESS = "SUCCESS";//SONAR MODIFICATION
	private static final String UNSOLD = "UNSOLD";////SONAR MODIFICATION

	// COMMENTED : PHASE 1+

	private static Logger logger = LogManager.getLogger(DIDIEligibilityServiceImpl.class);

	public DIDIEligibilityServiceImpl() {
		super();
	}

	@Override
	public DIDIResponse didiEligibilityService(DIDIRequestBean requestBean) {
		logger.debug("Entering DIDIEligibilityService : DIDIEligibilityService");

		String vin = "";
		String dealerMarket = "";
		String dealerCode = "";
		String dealerZone = "";
		String dealerLanguage = "";
		String source = "";
		String lop = "";
		String inServiceDate = "";
		// COMMENTED : PHASE 1+
		// ADDED START : PHASE 1+
		String logon = "";
		String reasonForNonEligibility = "";
		String nonEligibleDIDIFlag = "N";
		String nonEligibleDIDIMessage = "DIDI IS NOT ELIGIBLE";
		// ADDED END : PHASE 1+
		try {
			if (null != requestBean) {
				logger.debug("DIDIEligibilityService : DIDIEligibilityService : null != requestBean");

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 1");
				if (null != requestBean.getVin()) {
					vin = requestBean.getVin().trim().toUpperCase(); // MODIFIED : PHASE 1+
					requestBean.setVin(vin);
				}

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 2");
				if (null != requestBean.getDealerMarket()) {
					dealerMarket = requestBean.getDealerMarket().trim().toUpperCase(); // MODIFIED : PHASE 1+
					requestBean.setDealerMarket(dealerMarket);
				}

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 3");
				if (null != requestBean.getDealerCode()) {
					dealerCode = requestBean.getDealerCode().trim().toUpperCase(); // MODIFIED : PHASE 1+
					requestBean.setDealerCode(dealerCode);
				}

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 4");
				if (null != requestBean.getDealerZone()) {
					dealerZone = requestBean.getDealerZone().trim().toUpperCase(); // MODIFIED : PHASE 1+
					requestBean.setDealerZone(dealerZone);
				}

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 5");
				if (null != requestBean.getDealerLanguage()) {
					dealerLanguage = requestBean.getDealerLanguage().trim().toUpperCase(); // MODIFIED : PHASE 1+
					requestBean.setDealerLanguage(dealerLanguage);
				}

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 6");
				if (null != requestBean.getSource()) {
					source = requestBean.getSource().trim().toUpperCase(); // MODIFIED : PHASE 1+
					requestBean.setSource(source);
				}

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 7");
				if (null != requestBean.getLop()) {
					lop = requestBean.getLop().trim().toUpperCase(); // MODIFIED : PHASE 1+
					requestBean.setLop(lop);
				}

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 8");
				if (null != requestBean.getInServiceDate()) {
					inServiceDate = requestBean.getInServiceDate().trim().toUpperCase(); // MODIFIED : PHASE 1+
					requestBean.setInServiceDate(inServiceDate);
				}

				// COMMENTED : PHASE 1+

				// ADDED START : PHASE 1+
				if (null != requestBean.getLogon()) {
					logon = requestBean.getLogon().trim().toUpperCase();
					requestBean.setLogon(logon);
				}

				// ADDED END : PHASE 1+

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 10 DIDIResponse {}",
						didiResponse);
				didiResponse.setVin(vin);
				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 10-1");
				didiResponse.setDealerMarket(dealerMarket);
				didiResponse.setDealerCode(dealerCode);
				didiResponse.setDealerZone(dealerZone);
				didiResponse.setDealerLanguage(dealerLanguage);
				didiResponse.setSource(source);
				didiResponse.setLop(lop);
				didiResponse.setInServiceDate(inServiceDate);
				// COMMENTED : PHASE 1+
				didiResponse.setDidiEligiblityFlag(nonEligibleDIDIFlag); // MODIFIED : PHASE 1+
				didiResponse.setDidiEligiblityMessage(nonEligibleDIDIMessage); // MODIFIED : PHASE 1+
				// ADDED START PHASE 1+
				didiResponse.setLogon(logon);
				didiResponse.setRoData(requestBean.getRoData());
				// ADDED END PHASE 1+

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 11");
				// COMMENTED : PHASE 1+

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 12");
				int vinValidation = validation.validatevinNumber(vin);

				if (-1 != vinValidation) {
					didiResponse.setResponseCode("0");
					didiResponse.setResponseMessage(SUCCESS);
				} else {
					reasonForNonEligibility = "17 CHARACTERS OF VIN IS MANDATORY"; // ADDED : PHASE 1+
					didiResponse.setResponseCode("1");
					didiResponse.setResponseMessage(reasonForNonEligibility); // MODIFIED : PHASE 1+
					return didiResponse;

				}

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 13");
				if (!"".equalsIgnoreCase(dealerMarket)) {
					int marketValidation = validation.validateDealerMarket(dealerMarket);
					if (-1 != marketValidation) {
						didiResponse.setResponseCode("0");
						didiResponse.setResponseMessage(SUCCESS);
					} else {
						reasonForNonEligibility = "VALID DEALER MARKET IS EXPECTED"; // ADDED : PHASE 1+
						didiResponse.setResponseCode("2");
						didiResponse.setResponseMessage(reasonForNonEligibility); // MODIFIED : PHASE 1+
						return didiResponse;

					}
				}

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 14");
				if (!"".equalsIgnoreCase(dealerCode)) {
					int dealerCodeValidation = validation.validateDealerCode(dealerCode, 5, 5);

					if (-1 != dealerCodeValidation) {
						didiResponse.setResponseCode("0");
						didiResponse.setResponseMessage(SUCCESS);
					} else {
						reasonForNonEligibility = "5 CHARACTERS OF DEALERCODE IS EXPECTED"; // ADDED : PHASE 1+
						didiResponse.setResponseCode("3");
						didiResponse.setResponseMessage(reasonForNonEligibility); // MODIFIED : PHASE 1+
						return didiResponse;

					}
				}

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 15");
				if (!"".equalsIgnoreCase(dealerZone)) {
					int dealerZoneValidation = validation.validateDealerZone(dealerZone, 2, 2);

					if (-1 != dealerZoneValidation) {
						didiResponse.setResponseCode("0");
						didiResponse.setResponseMessage(SUCCESS);
					} else {
						reasonForNonEligibility = "2 CHARACTERS OF DEALER ZONE IS EXPECTED"; // ADDED : PHASE 1+
						didiResponse.setResponseCode("4");
						didiResponse.setResponseMessage(reasonForNonEligibility); // MODIFIED : PHASE 1+
						return didiResponse;

					}
				}

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 16");
				if (!"".equalsIgnoreCase(dealerLanguage)) {
					int dealerLanguageValidation = validation.validateDealerLanguage(dealerLanguage, 3, 3);

					if (-1 != dealerLanguageValidation) {
						didiResponse.setResponseCode("0");
						didiResponse.setResponseMessage(SUCCESS);
					} else {
						reasonForNonEligibility = "3 CHARACTERS OF DEALER LANGUAGE IS EXPECTED"; // ADDED : PHASE 1+
						didiResponse.setResponseCode("3");
						didiResponse.setResponseMessage(reasonForNonEligibility); // MODIFIED : PHASE 1+
						return didiResponse;

					}
				}

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 17");
				int sourceValidation = validation.validateSource(source, 5, 4); // MODIFIED : PHASE 1+
				if (-1 != sourceValidation) {
					didiResponse.setResponseCode("0");
					didiResponse.setResponseMessage(SUCCESS);
				} else {
					reasonForNonEligibility = "VALID SOURCE IS MANDATORY"; // ADDED : PHASE 1+
					didiResponse.setResponseCode("6");
					didiResponse.setResponseMessage(reasonForNonEligibility); // MODIFIED : PHASE 1+
					return didiResponse;

				}

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 18");
				if (!"".equalsIgnoreCase(lop)) {
					int lopValidation = validation.validateLop(lop);

					if (-1 != lopValidation) {
						didiResponse.setResponseCode("0");
						didiResponse.setResponseMessage(SUCCESS);
					} else {
						reasonForNonEligibility = "VALID LOP OF 2/4/6/8 CHARACTERS IS MANDATORY"; // ADDED : PHASE 1+
						didiResponse.setResponseCode("7");
						didiResponse.setResponseMessage(reasonForNonEligibility); // MODIFIED : PHASE 1+
						return didiResponse;

					}
				}

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 19");
				if (!"".equalsIgnoreCase(inServiceDate)) { // ADDED : PHASE 1+
					int inServiceDateValidation = validation.isValidDate(inServiceDate); // START PHASE 1+
					if (-1 != inServiceDateValidation) {
						didiResponse.setResponseCode("0");
						didiResponse.setResponseMessage(SUCCESS);
					} else {
						reasonForNonEligibility = "VALID IN-SERVICE DATE IS MANDATORY IN THE FORMAT YYYY-MM-DD"; // ADDED
						didiResponse.setResponseCode("8");
						didiResponse.setResponseMessage(reasonForNonEligibility); // MODIFIED : PHASE 1+
						return didiResponse;

					}
					// ADDED START : PHASE 1+
				} else {
					inServiceDate = getInServiceDate(vin);
					requestBean.setInServiceDate(inServiceDate);
				}
				// ADDED END : PHASE 1+

				// ADDED START : PHASE 1+
				if (null != requestBean.getRoData()) {
					List<RepairOrderBean> roList = requestBean.getRoData();
					int roDateValidation = 0;

					for (RepairOrderBean roBean : roList) {
						if (null != roBean.getOpenDate() && !"".equalsIgnoreCase(roBean.getOpenDate())) {
							roDateValidation = validation.isValidDate(roBean.getOpenDate());
							if (-1 != roDateValidation) {
								didiResponse.setResponseCode("0");
								didiResponse.setResponseMessage(SUCCESS);
							} else {
								reasonForNonEligibility = "VALID RO OPEN-DATE IS MANDATORY IN THE FORMAT YYYY-MM-DD, PLEASE ENSURE CORRECT RO OPEN DATE FOR ALL ROS";
								didiResponse.setResponseCode("8");
								didiResponse.setResponseMessage(reasonForNonEligibility); // MODIFIED : PHASE 1+
								return didiResponse;

							}
						}
					}

				}
				// ADDED END : PHASE 1+

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 20");
				// COMMENTED : PHASE 1+

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 21");
				DIDIResponseBean bean;
				// COMMENTED : PHASE 1+
				bean = setDataInResponse(requestBean);
				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 51");

				// ADDED START : PHASE 1+
				String vinLevelDIDIEligibilityFlag = bean.getdidiEligibilityFlag();
				String vinLevelDIDIEligibilityMessage = bean.getdidiMessage();
				reasonForNonEligibility = bean.getReasonForNonEligibility();
				int misFromTheParm = Integer.parseInt(bean.getMisFromTheParm());
				// ADDED END : PHASE 1+

				didiResponse.setDidiEligiblityFlag(vinLevelDIDIEligibilityFlag);
				didiResponse.setDidiEligiblityMessage(vinLevelDIDIEligibilityMessage);
				didiResponse.setResponseCode(bean.getResponseCode());
				didiResponse.setResponseMessage(bean.getResponseMessage());

				// ADDED START : PHASE 1+

				if ("N".equalsIgnoreCase(vinLevelDIDIEligibilityFlag)
						|| "O".equalsIgnoreCase(vinLevelDIDIEligibilityFlag)) {
					didiResponse.setDidiEligiblityFlag(nonEligibleDIDIFlag);
					didiResponse.setDidiEligiblityMessage(nonEligibleDIDIMessage);
				}

				logger.debug("DIDIEligibilityService : DIDIEligibilityService : mis present in the table {}",
						misFromTheParm);
				int misAtROAndLNLevel = 0;
				String serviceType = "";
				String opsCode = ""; // ADDED : PHASE 1+ : NEW CHANGES
				List<RepairOrderBean> roBeans = didiResponse.getRoData();
				logger.info("returning from DIDIEligibilityServiceImpl class :DIDIEligibilityService Method");
				for (RepairOrderBean ro : roBeans) {
					serviceType = ro.getServiceType();
					opsCode = ro.getOpsCode();

					// ADDED START : PHASE 1.2
					if (null == opsCode)
						opsCode = "";
					// ADDED END : PHASE 1.2

					// ADDED START : PHASE 1+ : NEW CHANGES
					// MODIFIED START : PHASE 1+ : NEW CHANGES
					if (opsCode.startsWith("CLEAN") || opsCode.startsWith("PDI") // MODIFIED : PHASE 1.2
							|| opsCode.startsWith("NVP") || opsCode.startsWith("NVC") // MODIFIED : PHASE 1.2
							|| opsCode.startsWith("BATTMAIN") || opsCode.startsWith("BATMAINT") // ADDED : PHASE 1.2
							|| "080801PC".equalsIgnoreCase(opsCode)
							|| "N".equalsIgnoreCase(vinLevelDIDIEligibilityFlag)) {

						ro.setDIDIEligibilityFlag(nonEligibleDIDIFlag);
						ro.setDidiMessage(nonEligibleDIDIMessage);
						String rollNumber = reasonForNonEligibility + "::" + ro.getRoNumber() + ":"
								+ ro.getLineItemNumber() + ":OPS CODE " + opsCode;
						reasonForNonEligibility = rollNumber;//SONAR MODIFICATION

					}
					// ADDED END : PHASE 1+ : NEW CHANGES
					else if ("R".equalsIgnoreCase(serviceType) || "RM".equalsIgnoreCase(serviceType) // MODIFIED : PHASE
																										// 1+ : NEW
																										// CHANGES
							|| "N".equalsIgnoreCase(vinLevelDIDIEligibilityFlag)) {

						ro.setDIDIEligibilityFlag(nonEligibleDIDIFlag);
						ro.setDidiMessage(nonEligibleDIDIMessage);
						String rollNumber = reasonForNonEligibility + "::" + ro.getRoNumber() + ":"
								+ ro.getLineItemNumber() + ":SERV TYPE " + serviceType;
						reasonForNonEligibility = rollNumber;//SONAR MODIFICATION

					} else if ("Y".equalsIgnoreCase(vinLevelDIDIEligibilityFlag)) {

						ro.setDIDIEligibilityFlag(vinLevelDIDIEligibilityFlag);
						ro.setDidiMessage(vinLevelDIDIEligibilityMessage);

					} else if ("O".equalsIgnoreCase(vinLevelDIDIEligibilityFlag)) {
						logger.debug(
								"DIDIEligibilityService : DIDIEligibilityService : requestBean.getInServiceDate() {} ro.getOpenDate() {}",
								requestBean.getInServiceDate(), ro.getOpenDate());
						misAtROAndLNLevel = calculateMISAtROAndLN(requestBean.getInServiceDate(), ro.getOpenDate()); // MODIFIED
																														// :
																														// PHASE
																														// 1+

						if (misFromTheParm >= misAtROAndLNLevel) {
							ro.setDIDIEligibilityFlag("Y");
							ro.setDidiMessage(vinLevelDIDIEligibilityMessage);
						} else {
							ro.setDIDIEligibilityFlag(nonEligibleDIDIFlag);
							ro.setDidiMessage(nonEligibleDIDIMessage);
							String rollNumber = reasonForNonEligibility + "::" + ro.getRoNumber() + ":"
									+ ro.getLineItemNumber() + ":OUT OF MIS";
							reasonForNonEligibility = rollNumber;//SONAR MODIFICATION
						}

					}

				}

				didiResponse.setRoData(roBeans);
				logger.debug("didiResponse.setRoData - {}", didiResponse.getRoData());
				// ADDED END : PHASE 1+

				didiResponse.setResponseCode("0");
				didiResponse.setResponseMessage(SUCCESS);

				logger.debug("Exiting DIDIEligibilityService : DIDIEligibilityService");
				// COMMENTED : PHASE 1+

				return didiResponse;

			} else {
				logger.error("Error DIDIEligibilityService : DIDIEligibilityServiceImpl :: Parent catch block");
				reasonForNonEligibility = "FAILURE - REQUEST IS NULL"; // ADDED : PHASE 1+
				didiResponse.setResponseCode("1");
				didiResponse.setResponseMessage(reasonForNonEligibility); // MODIFIED : PHASE 1+
			}
			logger.info("returning from DIDIEligibilityService method ");
		} catch (DIDIException e) {
			logger.error("Error DIDIEligibilityService : DIDIEligibilityServiceImpl :: Parent catch block");
			reasonForNonEligibility = "FAILURE - EXCEPTION ENCOUNTERED " + e.getMessage(); // ADDED : PHASE 1+
			didiResponse.setResponseCode("1");
			didiResponse.setResponseMessage(reasonForNonEligibility); // MODIFIED : PHASE 1+
		} finally {
			//SONAR MODIFICATION START
			InsertIntoAuditTableBean auditTableBean = new InsertIntoAuditTableBean();
			auditTableBean.setMarket(dealerMarket);
			auditTableBean.setDealer(dealerCode);
			auditTableBean.setZone(dealerZone);
			auditTableBean.setLang(dealerLanguage);
			auditTableBean.setDidiResponseBean(didiResponse);
			auditTableBean.setVin(vin);
			auditTableBean.setSource(source);
			auditTableBean.setLop(lop);
			auditTableBean.setInServiceDate(requestBean.getInServiceDate());
			auditTableBean.setReasonForNonEligibility(reasonForNonEligibility);

			insertIntoAuditTable(auditTableBean);
			
			//SONAR MODIFICATION END
		}
            logger.info("returning from DIDIEligibilityServiceImpl:DIDIEligibilityService ");
		return didiResponse;
	}

	private DIDIResponseBean setDataInResponse(DIDIRequestBean requestBean) throws DIDIException {
		logger.debug("Entering DIDIEligibilityService : setDataInResponce");
		DIDIResponseBean didiResponseBean = new DIDIResponseBean();
		logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 22");
		if (requestBean.getLop() != null && !requestBean.getLop().isEmpty()) {
			logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 23");
			Map<String, String> responseOnLop = validation.getFlagOnLop(requestBean.getLop());
			if (responseOnLop != null && !responseOnLop.isEmpty()) {
				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 24");
				if (responseOnLop.containsKey("eligFlag") && responseOnLop.containsKey("message")) {
					logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 25");
					didiResponseBean.setdidiEligibilityFlag(responseOnLop.get("eligFlag"));
					didiResponseBean.setdidiMessage(responseOnLop.get("message"));
					didiResponseBean.setResponseCode("0");
					didiResponseBean.setResponseMessage(SUCCESS);
				} else {
					logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 26");
					didiResponseBean = this.setResponseIfProcessContinues( requestBean);
				}
			} else {
				logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 27");
				didiResponseBean = this.setResponseIfProcessContinues( requestBean);
			}
		} else {
			logger.debug("DIDIEligibilityService : DIDIEligibilityService : Point 28");
			didiResponseBean = this.setResponseIfProcessContinues( requestBean);
		}
		logger.debug("Exiting DIDIEligibilityService : setDataInResponce");

		return didiResponseBean;
	}

	public DIDIResponseBean setResponseIfProcessContinues( DIDIRequestBean requestBean)
			throws DIDIException {
		//DIDIResponseBean responseBeanLocal = responseBean;	// ADDED : PHASE 2 : SONAR FIX
		logger.debug("Entering DIDIEligibilityService : setResponseIfProcessContinues");
		Map<String, Object> dataMap = null;
		logger.debug("DIDIEligibilityService : setResponseIfProcessContinues : Point 29");
		dataMap = new VipBasicServiceAWSCloud().getVehicle(requestBean.getVin());
		logger.debug("DIDIEligibilityService : setResponseIfProcessContinues : Point 38");
		// ADDED START : PHASE 1+
		String mis = "";
		if (UNSOLD.equalsIgnoreCase(requestBean.getInServiceDate()))
			mis = "0";
		else
			// ADDED END : PHASE 1+
			mis = calculateMIS(requestBean); // MODIFIED : PHASE 1+
		logger.debug("DIDIEligibilityService : setResponseIfProcessContinues : Point 39");
		// COMMENTED : PHASE 1+
		dataMap.put("MIS", mis);
		dataMap.put("requestBean", requestBean);
		logger.debug("DIDIEligibilityService : setResponseIfProcessContinues : Point 40");
		String lop = requestBean.getLop();
		int lopLength = lop.length();
		String lop12 = "";
		String lop34 = "";
		String lop56 = "";
		String lop78 = "";
		logger.debug("DIDIEligibilityService : setResponseIfProcessContinues : Point 41");
		if (2 == lopLength) {
			lop12 = requestBean.getLop();
		} else if (4 == lopLength) {
			lop12 = requestBean.getLop().substring(0, 2);
			lop34 = requestBean.getLop().substring(2, 4);
		} else if (6 == lopLength) {
			lop12 = requestBean.getLop().substring(0, 2);
			lop34 = requestBean.getLop().substring(2, 4);
			lop56 = requestBean.getLop().substring(4, 6);
		} else if (8 == lopLength) {
			lop12 = requestBean.getLop().substring(0, 2);
			lop34 = requestBean.getLop().substring(2, 4);
			lop56 = requestBean.getLop().substring(4, 6);
			lop78 = requestBean.getLop().substring(6, 8);
		}
		logger.debug("DIDIEligibilityService : setResponseIfProcessContinues : Point 42");
		dataMap.put("lop12", lop12);
		dataMap.put("lop34", lop34);
		dataMap.put("lop56", lop56);
		dataMap.put("lop78", lop78);
		logger.debug("DIDIEligibilityService : setResponseIfProcessContinues : dataMap {}", dataMap);
		DIDIResponseBean responseBeanLocal = compareDataMapWithParm(dataMap);	// MODIFIED : PHASE 2 : SONAR FIX
		logger.debug("DIDIEligibilityService : setResponseIfProcessContinues : Point 50");
		logger.debug("Exiting DIDIEligibilityService : setResponseIfProcessContinues");
		return responseBeanLocal;	// MODIFIED : PHASE 2 : SONAR FIX
	}

	public String calculateMIS(DIDIRequestBean requestBean) throws DIDIException {
		logger.debug("Entering DIDIEligibilityService : calculateMIS");
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		String mis = "";
		try {

			Date inServiceDate = dateFormat.parse(requestBean.getInServiceDate());
			Date runDate = new Date(); // MODIFIED : PHASE 1+

			// COMMENTED : PHASE 1+

			long differenceInDays = (runDate.getTime() - inServiceDate.getTime()) / (24 * 60 * 60 * 1000);
			logger.debug("Entering DIDIEligibilityService : calculateMIS - differenceInDays {}", differenceInDays);
			mis = Integer.toString((int) ((differenceInDays / 30.416) + 0.99));

			logger.debug("Exiting DIDIEligibilityService : calculateMIS - mis {}", mis);
		} catch (ParseException e) {
			new DIDIExceptionHandler()
					.throwDIDIException("DIDIEligibilityService : setResponseIfProcessContinues :: " + e.getMessage());
		}
		return mis;

	}

	// ADDED START : PHASE 1+

	public int calculateMISAtROAndLN(String inServiceDate, String openDate) throws DIDIException {
		logger.debug("Entering DIDIEligibilityService : calculateMISAtROAndLN");
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		int misAtROandLN = 0;
		try {

			Date inServiceDateLocal = dateFormat.parse(inServiceDate);
			String openDateLocal = openDate.trim();
			Date runDate = null;

			if (null != openDateLocal && !"".equalsIgnoreCase(openDateLocal))
				runDate = dateFormat.parse(openDateLocal);
			else
				runDate = new Date();

			long differenceInDays = (runDate.getTime() - inServiceDateLocal.getTime()) / (24 * 60 * 60 * 1000);
			logger.debug("Entering DIDIEligibilityService : calculateMISAtROAndLN - differenceInDays {}",
					differenceInDays);
			misAtROandLN = (int) ((differenceInDays / 30.416) + 0.99);

			logger.debug("Exiting DIDIEligibilityService : calculateMISAtROAndLN - mis {}", misAtROandLN);
		} catch (ParseException e) {
			new DIDIExceptionHandler()
					.throwDIDIException("DIDIEligibilityServiceImpl : calculateMISAtROAndLN :: " + e.getMessage());
		}
		return misAtROandLN;

	}

	// ADDED END : PHASE 1+

	private DIDIResponseBean compareDataMapWithParm(Map<String, Object> dataMap)//SONAR MODIFICATION -REMOVED DIDIRequestBean bean
			throws DIDIException {
		logger.debug("Entering DIDIEligibilityService : compareDataMapWithParm");
		Map<Integer, Map<String, String>> parmData = parmService.getParmData(dataMap);
		logger.debug("DIDIEligibilityService : compareDataMapWithParm : Point 43");

		DIDIResponseBean didiResponseBean = new DIDIResponseBean();

		String mis = "";

		// ADDED START : PHASE 1+
		String didiEligibilityFlag = "N";
		String didiEligibilityMessage = "DIDI IS NOT ELIGIBLE";
		// ADDED END : PHASE 1+

		if (parmData.isEmpty()) {
			logger.debug("DIDIEligibilityService : compareDataMapWithParm : Point 44");
			didiResponseBean.setdidiEligibilityFlag(didiEligibilityFlag); // MODIFIED : PHASE 1+
			didiResponseBean.setdidiMessage(didiEligibilityMessage); // MODIFIED : PHASE 1+
			didiResponseBean.setReasonForNonEligibility("VEHICLE IS NOT PRESENT IN THE PARM");
		} else {
			logger.debug("DIDIEligibilityService : compareDataMapWithParm : Point 45");
			for (Entry<Integer, Map<String, String>> eachColumn : parmData.entrySet()) {

				logger.debug("DIDIEligibilityService : compareDataMapWithParm : eachColumn {}", eachColumn);

				mis = eachColumn.getValue().get("Q_MIS");

				// ADDED START : PHASE 1+
				didiEligibilityFlag = eachColumn.getValue().get("L_ELIG").trim();
				didiEligibilityMessage = eachColumn.getValue().get("X_MSG").trim();
				didiResponseBean.setMisFromTheParm(mis);
				logger.debug("DIDIEligibilityService : compareDataMapWithParm : mis present in the table {}", mis);
				if ("N".equalsIgnoreCase(didiEligibilityFlag)) {
					didiResponseBean.setdidiEligibilityFlag(didiEligibilityFlag);
					didiResponseBean.setdidiMessage(didiEligibilityMessage);
					didiResponseBean.setReasonForNonEligibility(didiEligibilityMessage);
				}
				// ADDED END : PHASE 1+
				// COMMENTED : PHASE 1+
				else if (Integer.parseInt(mis) >= Integer.parseInt((String) dataMap.get("MIS"))) { // MODIFIED : PHASE
																									// 1+
					logger.debug("DIDIEligibilityService : compareDataMapWithParm : Point 47");
					didiResponseBean.setdidiEligibilityFlag(didiEligibilityFlag); // MODIFIED : PHASE 1+
					didiResponseBean.setdidiMessage(didiEligibilityMessage); // MODIFIED : PHASE 1+
				} else {
					logger.debug("DIDIEligibilityService : compareDataMapWithParm : Point 48");
					// MODIFIED START : PHASE 1+
					didiResponseBean.setdidiEligibilityFlag("O");
					didiResponseBean.setdidiMessage(didiEligibilityMessage);
					didiResponseBean.setReasonForNonEligibility("VEHICLE IS OUT OF MIS");
					// MODIFIED END : PHASE 1+
				}
				logger.debug("DIDIEligibilityService : compareDataMapWithParm : Point 49");
			}
		}

		logger.debug("Entering DIDIEligibilityService : compareDataMapWithParm sorted Parm data {}", parmData);
		return didiResponseBean;
	}
	//SONAR MODIFICATION START
	private void insertIntoAuditTable(InsertIntoAuditTableBean insertIntoAuditTable) {
		String market = insertIntoAuditTable.getMarket();
		String dealer = insertIntoAuditTable.getDealer();
		String zone = insertIntoAuditTable.getZone();
		String lang = insertIntoAuditTable.getLang();
		DIDIResponse didiResponseBean = insertIntoAuditTable.getDidiResponseBean();
		String vin = insertIntoAuditTable.getVin();
		String source = insertIntoAuditTable.getSource();
		String lop = insertIntoAuditTable.getLop();
		String inServiceDate = insertIntoAuditTable.getInServiceDate();
		String reasonForNonEligibility = insertIntoAuditTable.getReasonForNonEligibility();
		
		//SONAR MODIFICATION END
		
		String timestampInEST = formatDateToString(new java.util.Date(), "yyyy-MM-dd HH:mm:ss", "EST"); // MODIFIED :
																										// PHASE 1+

		// COMMENTED : PHASE 1+

		//SONAR MODIFICATION START
				String sqlQuery = "INSERT INTO SDIDAUDIT (C_VIN, C_MKT, C_DLR, C_ZONE, C_LANG, C_SRC, C_LOP, D_IN_SRVC, L_ELIG, X_MSG,X_RSN,I_LOGON_ADD,T_STMP_PROC)"
						+ " VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,? ,?)";
				jdbcTemplate.update(sqlQuery, vin, market, dealer, zone, lang, source, lop, inServiceDate,
						didiResponseBean.getDidiEligiblityFlag(), didiResponseBean.getDidiEligiblityMessage(),
						reasonForNonEligibility, didiResponseBean.getLogon(), timestampInEST);
			}
		//SONAR MODIFICATION END 
	
	public String formatDateToString(Date date, String format, String timeZone) {
		if (date == null)
			return null;
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		if (timeZone == null || "".equalsIgnoreCase(timeZone.trim())) {
			timeZone = Calendar.getInstance().getTimeZone().getID();
		}
		sdf.setTimeZone(TimeZone.getTimeZone(timeZone));
		return sdf.format(date);
	}

	// ADDED START : PHASE 1+
	public String getInServiceDate(String vin) throws DIDIException {
		logger.debug("Entering DIDIEligibilityService : getInServiceDate");
		String returnInServiceDate = "";
		Map<String, String> data = new HashMap<>();
		logger.debug("DIDIEligibilityService : getInServiceDate Point 101 VIN {}", vin);
		String iVHCLSAN = "I_VHCL_SAN";// MODIFIED
		String iPRTITN = "I_PRTITN";// MODIFIED
		String lVHCLSOLD = "L_VHCL_SOLD";// MODIFIED

		String vehicleTableQueryBuilder = "SELECT I_VHCL_SAN, I_PRTITN, L_VHCL_SOLD FROM SVEHW WHERE I_VIN = ?";
		String claimTableQueryBuilder = "SELECT D_VHCL_IN_SERV, D_WARR_STRT FROM SVEHCLM WHERE I_VHCL_SAN = ? AND I_PRTITN = ?";
		logger.debug("DIDIEligibilityService : getInServiceDate Point 102 ");
		try {
			logger.debug("DIDIEligibilityService : getInServiceDate sql before vehicleTableQueryBuilder {}",
					vehicleTableQueryBuilder);
			jdbcTemplate.query(vehicleTableQueryBuilder, new PreparedStatementSetter() {
				public void setValues(PreparedStatement preparedStatement) throws SQLException {
					preparedStatement.setString(1, vin);
				}
			}, rs -> {
				String vehicleSAN = rs.getString(iVHCLSAN).trim();
				String partition = rs.getString(iPRTITN).trim();
				String soldFlag = rs.getString(lVHCLSOLD).trim();
				logger.debug("I_VHCL_SAN {} I_PRTITN {} L_VHCL_SOLD {}", vehicleSAN, partition, soldFlag);
				data.put(iVHCLSAN, vehicleSAN);
				data.put(iPRTITN, partition);
				data.put(lVHCLSOLD, soldFlag);
			});

			String vehicleSANLocal = data.get(iVHCLSAN);
			String partitionLocal = data.get(iPRTITN);
			String soldFlagLocal = data.get(lVHCLSOLD);

			logger.debug("vehicleSANLocal {} partitionLocal {} soldFlagLocal {}", vehicleSANLocal, partitionLocal,
					soldFlagLocal);

			if (!"X".equalsIgnoreCase(soldFlagLocal)) {
				logger.debug("return UNSOLD");
				return UNSOLD;
			}

			if (null != vehicleSANLocal && !"".equalsIgnoreCase(vehicleSANLocal) && null != partitionLocal
					&& !"".equalsIgnoreCase(partitionLocal)) {
				
				logger.debug("DIDIEligibilityService : getInServiceDate sql before claimTableQueryBuilder {}",
						claimTableQueryBuilder);
				String inServiceDate="inServiceDate";
				jdbcTemplate.query(claimTableQueryBuilder, new PreparedStatementSetter() {
					public void setValues(PreparedStatement preparedStatement) throws SQLException {
						preparedStatement.setString(1, vehicleSANLocal);
						preparedStatement.setString(2, partitionLocal);
					}
				}, rs -> {
					 
					String inServiceDateLocal = rs.getString("D_VHCL_IN_SERV").trim();
					String warrantyStartLocal = rs.getString("D_WARR_STRT").trim();
					if (!"0001-01-01".equalsIgnoreCase(inServiceDateLocal))
						data.put(inServiceDate, inServiceDateLocal);
					else if (!"0001-01-01".equalsIgnoreCase(warrantyStartLocal))
						data.put(inServiceDate, warrantyStartLocal);
					else
						data.put(inServiceDate, UNSOLD);
				});
			}

			returnInServiceDate = data.get("inServiceDate");
		} catch (Exception e) {
			new DIDIExceptionHandler()
					.throwDIDIException("DIDIEligibilityService : getInServiceDate :: " + e.getMessage());
		}

		logger.debug("Exiting DIDIEligibilityService : getInServiceDate data returnInServiceDate {}",
				returnInServiceDate);
		return returnInServiceDate;
	}
	// ADDED END : PHASE 1+

}
